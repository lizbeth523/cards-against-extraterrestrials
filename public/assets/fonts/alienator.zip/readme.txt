Hello you.
----------

You've got your hands on the Alienator font.

Well Congratulations! Use it and don't freak out.

If you're going to use it commercially, have it on a CD, or
otherwise earn money with it, please contact me for info.

I'd like to get paid too...

... and I wouldn't like to sue you.

cosmonaut@icenet.fi
cosmonaut@hypenet.com


Thanks.
---


